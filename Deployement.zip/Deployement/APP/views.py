from django.shortcuts import render,redirect
from .forms import UserRegisterForm,UserImageForm,UserPersonalForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from .models import UserImageModel,UserPersonalModel
import numpy as np
from tensorflow import keras
from PIL import Image,ImageOps

# Create your views here.
def Landing_1(request):
    return render(request,"1_landing.html")
    
def Register_2(request):
    form = UserRegisterForm()
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Account was successfully created. ' + user)
            return redirect('Login_3')
        else:
            print("form error")

    context = {'form': form}
    return render(request, "2_Register.html", context)

    
def Login_3(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('Home_4')
        else:
            messages.info(request, 'Username OR Password incorrect')

    context = {}
    return render(request,"3_Login.html", context)
    
def Home_4(request):
    return render(request,"4_Home.html")

def Teamates_5(request):
    return render(request,"5_Teamates.html")

def Domain_Result_6(request):
    return render(request,"6_Domain_Result.html")

def Problem_Statement_7(request):
    return render(request,"7_Problem_Statement.html")
    
from django.contrib import messages
from .forms import UserPersonalForm

def Per_Info_8(request):
    if request.method == 'POST':
        form = UserPersonalForm(request.POST)
        if form.is_valid():
            print('Saving data in Form')
            form.save()
            # Redirect to a different page after successful form submission
            return render(request, '4_Home.html', {'form': form})
        else:
            # Print form errors to the console for debugging
            print(form.errors)
            # Add a message to inform the user about form errors
            messages.error(request, 'Please correct the errors in the form.')
    else:
        # This part of the code will execute for GET requests
        form = UserPersonalForm()

    # Render the '8_Per_Info.html' template with the form
    return render(request, '8_Per_Info.html', {'form': form})


def Database(request):
    models = UserImageModel.objects.all()
    return render(request, 'model_database.html', {'models': models})
    
def Deploy_9(request):
    if request.method == "POST":
        form = UserImageForm(files=request.FILES)
        if form.is_valid():
            form.save()
        obj = form.instance

        result1 = UserImageModel.objects.latest('id')
        models = keras.models.load_model('C:/Users/SPIRO25/Desktop/PROJECT/ITPDL05 - SATELIGHT/Deployement/APP/keras_model.h5')
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
        image = Image.open("C:/Users/SPIRO25/Desktop/PROJECT/ITPDL05 - SATELIGHT/Deployement/media/" + str(result1)).convert("RGB")
        size = (224, 224)
        image = ImageOps.fit(image, size, Image.ANTIALIAS)
        image_array = np.asarray(image)
        normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
        data[0] = normalized_image_array
        classes = ['cloudy','desert','green_area','shipsnet','water','wildfire']
        prediction = models.predict(data)
        idd = np.argmax(prediction)
        a = (classes[idd])
        if a == 'cloudy':
            a = 'cloudy'
        elif a == 'desert':
            a = 'desert'
        elif a == 'green_area':
            a = 'green_area'
        elif a == 'shipsnet':
            a = 'shipsnet'
        elif a == 'water':
            a = 'water'
        elif a == 'wildfire':
            a = 'wildfire'
        else:
            a = 'Give correct Images'

        data = UserImageModel.objects.latest('id')
        data.label = a
        data.save()
        return render(request, '9_Deploy.html',{'form':form,'obj':obj,'predict':a})
    else:
        form = UserImageForm()
    return render(request, '9_Deploy.html',{'form':form})
    
def Per_Database_10(request):
    models = UserPersonalModel.objects.all()
    return render(request,'10_Per_Database.html',{'models':models})

def Logout(request):
    if request.user.is_authenticated:
        logout(request)
    return redirect("Login_3")